from django.urls import path
from .views import full_chart_view

urlpatterns = [
    path('charts/', full_chart_view, name='species_chart'),
]
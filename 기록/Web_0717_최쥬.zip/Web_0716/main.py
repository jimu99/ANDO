def main():
    print("Hello from web!")


if __name__ == "__main__":
    main()

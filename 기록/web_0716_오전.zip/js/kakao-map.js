document.addEventListener("DOMContentLoaded", function () {
  // 카카오 지도 API가 로드됐는지 체크
  if (typeof kakao === "undefined") {
    console.error("Kakao Maps API가 로드되지 않았습니다.");
    return;
  }

  var container = document.getElementById('map');
  var options = {
    center: new kakao.maps.LatLng(37.5665, 126.9780),
    level: 5
  };

  var map = new kakao.maps.Map(container, options);

  var marker = new kakao.maps.Marker({
    position: new kakao.maps.LatLng(37.5665, 126.9780),
    map: map
  });
});

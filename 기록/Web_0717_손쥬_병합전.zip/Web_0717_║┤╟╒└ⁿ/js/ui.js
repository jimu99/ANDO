function showTab(n) {
  const tabs = document.querySelectorAll(".tab-content");
  tabs.forEach((tab) => (tab.style.display = "none"));

  const target = document.getElementById("tab" + n);
  if (target) target.style.display = "block";

  // ✅ 생태통로 탭이면 지도에 원 추가
if (window.map) {
  if (n === 2) {
    drawEcoCircles(window.map);    // ✅ 분류 2일 때만 그림
  } else {
    clearEcoCircles();             // ✅ 그 외 탭에서는 원 제거
  }
}

}

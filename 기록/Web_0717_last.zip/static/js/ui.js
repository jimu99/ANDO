function showTab(index) {
  const tabs = document.querySelectorAll(".tab-content");
  tabs.forEach((tab, i) => {
    tab.classList.toggle("active", i === index);
  });
}

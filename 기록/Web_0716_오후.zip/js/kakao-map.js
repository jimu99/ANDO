document.addEventListener("DOMContentLoaded", function () {
  var container = document.getElementById("map");
  var options = {
    center: new kakao.maps.LatLng(36.5665, 127.9780),
    level: 12,
  };

  var map = new kakao.maps.Map(container, options);

  // ✅ JSON 파일에서 중부선 경로 좌표 불러오기
  fetch("data/jungbu.json")
    .then((response) => response.json())
    .then((data) => {
      const linePath = data.map((p) =>
        new kakao.maps.LatLng(p.lat, p.lon)
      );

      const polyline = new kakao.maps.Polyline({
        path: linePath,
        strokeWeight: 5,
        strokeColor: "#FF0000",
        strokeOpacity: 0.8,
        strokeStyle: "solid",
      });      

      polyline.setMap(map);
    });

  var marker = new kakao.maps.Marker({
    position: new kakao.maps.LatLng(36.5665, 127.9780),
    map: map,
  });
});
